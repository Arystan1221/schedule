<?php

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/PHPClass.php to edit this template
 */

/**
 * Description of newPHPClass
 *
 * @author Arystan
 */
abstract class Config {
const HOST = 'localhost';
const DB_NAME = 'schedule';
const DB_USER = 'root';
const DB_PASSWORD = '';
}
